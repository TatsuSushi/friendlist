declare module '*.css';
declare module '*.scss';