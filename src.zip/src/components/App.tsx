import React, { Component } from 'react';
import { BrowserRouter, Route, Redirect } from 'react-router-dom';
import './../style.css';
import Header from './Header'
import ListView from './ListView'
import CardView from './CardView'
import axios from 'axios';

interface IAppProps{

}

interface IAppStates{
  isRunning: boolean;
  posts: []
}



class App extends Component<IAppProps, IAppStates> {

  constructor() {
    //@ts-ignore
    super();
    //@ts-ignore
    this.state = {
      posts: []
    };
  }


  componentDidMount() {
    axios.get(`http://www.json-generator.com/api/json/get/cqHzMtkErS?indent=2`).then(res => {
      console.log(res);
      const posts = res.data.data.friends;
      this.setState({ posts });
    });
  }

  state2 = {
    isRunning: false
  };

  render() {
    return (
      <BrowserRouter>
   
          <Header firstHeader={"List View"} secondHeader={`Profiles`}  />
          <Route exact path="/" render={() => <Redirect to="/listview" />} />
          <Route exact path="/listview" render={() => <ListView data={this.state.posts}/>} />
          <Route exact path="/cardview" render={() => <CardView data={this.state.posts} />} />
       
      </BrowserRouter>
    );
  }

}

export default App;
