import React, {PureComponent} from 'react';



export interface IPanelProps {
    show: boolean;
    biography: string;
    relationship: string;
}


class Panel extends PureComponent <IPanelProps>{


    render (){
        return (
            <div className = "panel" style={{display: this.props.show ? 'block' : 'none'}}>
                <span> <h3>Relationship</h3> <p style ={{wordBreak: 'break-word'}}>{this.props.relationship} </p> </span>
                <h3>Biography</h3> <p>{this.props.biography}</p>
            </div>
    
        );
    
    }
    
}

export default Panel;