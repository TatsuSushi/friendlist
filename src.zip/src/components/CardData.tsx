import React, { Component } from 'react';
import Profile from '../assets/profile.svg';
import Background from '../assets/card-bg.jpg';
import SplitName from './SplitName';
import GenderAge from './GenderAge';
import ViewMore from '../assets/view-more.svg';
import Panel from './Panel';

interface ICardDataProps{
    name : string;
    gender: string;
    age: string;
    relationship: string;
    biography: string;
}

interface ICardDataState{
    isRunning:boolean;
}

class CardData extends Component<ICardDataProps,ICardDataState> {
    state = {
        isRunning: false
    };

    handlePanelToggle = () => {
        console.log(`toggling`);
        this.setState(prevState => ({
            isRunning: !prevState.isRunning
        }));
    }

    render() {
        return (
            <div className="card">
                <div style={{ position: 'relative' }}>
                    <img src={Background} style={{ width: "100%" }} className="cardBG" alt="background" />
                    <img src={Profile} className="cardProfile " alt="cardProfile" />

                </div>

                <div className="container">
                    <div className="marginCard">
                        <SplitName name={this.props.name} />
                    </div>
                </div>
                <div className="genderAgeCard marginCard">
                    <GenderAge gender={this.props.gender} age={this.props.age} />
                </div>
                <span>
                    <input type="image" src={ViewMore} className="image viewMore" alt="view more" onClick={this.handlePanelToggle} />
                </span>
                <div className="panel">
                    <Panel show={this.state.isRunning} relationship={this.props.relationship} biography={this.props.biography} />
                </div>
            </div>
        );

    }

}

export default CardData;