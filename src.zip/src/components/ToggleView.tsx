import React, {PureComponent} from 'react';
import Toggle from '../assets/toggle.svg';
import ActiveToggle from '../assets/toggle-active.svg'
import { NavLink } from 'react-router-dom';

interface IToggleViewProps{}

interface IToggleViewStates{
    isRunning: boolean;
}

class ToggleView extends PureComponent<IToggleViewProps, IToggleViewStates>{
    state = {
        isRunning: false
      };

      handleViewToggle = () => {
        console.log(`toggling`);
        this.setState(prevState => ({
            isRunning: !prevState.isRunning
        }));
    }
    
    render () {
        return(
            <>
            <NavLink to={this.state.isRunning ? "/listview": "/cardview" }> <input type="image" onClick = {this.handleViewToggle}  className="toggle" src={this.state.isRunning ? Toggle: ActiveToggle} alt="Toggle" /> </NavLink>
            </>
        );
    }
}

export default ToggleView;