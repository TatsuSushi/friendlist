import React, { Component } from 'react';
import CardLoop from './CardLoop';
import CardLoop2 from './CardLoop2';

interface ICardViewProps{
    data :[];
}

class CardView extends Component<ICardViewProps> {
    state = {
        isRunning: false
    };

    render() {
        return (
            <>
                <div className="cardView row">
                    <div className="col-6 d-flex flex-column"> {/*1st column */}
                        <div className="col">
                        <CardLoop data ={this.props.data} />

                        </div>
                    </div>
                    <div className="col-6 d-flex flex-column"> {/* 2nd column */}
                    <div className="col">
                    <CardLoop2 data ={this.props.data} />
                    </div>
                    
                    </div>
                </div>
                <div>
                </div>
            </>
        );
    }
}

export default CardView;