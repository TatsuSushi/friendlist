import React from 'react';
import ToggleView from './ToggleView';

interface IHeader {
    firstHeader: string,
    secondHeader: string
}

const Header = (props: IHeader) => {

    return (
        <header>
            <h1>{props.firstHeader} </h1>
           <ToggleView />
            <h2 className={`profile-h`}>{props.secondHeader}</h2>
        </header>
    );
}
Header.defaultProps = {
    firstHeader: 'View'
};

export default Header;